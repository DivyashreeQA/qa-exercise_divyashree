# QA Exercise - Order Executor

#### A new user story has come into the sprint:

`"As a trader, I want an application that can execute an order of allocations at the current market price, So that I can trade more efficiently."`

#### The analysis has been done and requirements gathered:

* An `Order` can have multiple `Allocations`.
* An `Allocation` has a `symbol`, `maturity date` and an `amount`.
* The application should be able execute an order total at the current market price and return the `Execution` result.
* An `Execution` result has a `symbol`, `maturity date`, `total amount` and a `price` that the order was execute at.

`Orders` being executed must:
* Have at least 1 allocation
* Have allocations with the same symbol
* Have allocations with the same maturity date
* Not net to zero

#### The application has been built by the developers:

Example (OrderExecutorDemo.java):
```java
    // Create access to some market prices 
    MarketPrices marketPrices = new RandomMarketPrices(); // Random and Fixed stub implementations exist for testing purposes 

    // Create the order executor application
    OrderExecutor executor = new OrderExecutor(marketPrices);

    // The order to execute (has 3 allocations)
    Order order = Order.of(
          Allocation.of("EURGBP", LocalDate.of(2021, 4, 28),  1_000_000),
          Allocation.of("EURGBP", LocalDate.of(2021, 4, 28), -2_000_000),
          Allocation.of("EURGBP", LocalDate.of(2021, 4, 28),  3_000_000));

    // Execute the order
    Execution execution = executor.execute(order);

    // Outputs "Execution{symbol='EURGBP', maturity=2021-04-28, amount=2000000, price=1.2629889072539489}"
    System.out.println(execution); 
```

#### The Exercise

This project contains the source code for the Java order executor application.

Please complete the following tasks and return the project files as a zip file:

* Write the Acceptance criteria that could accompany the story (_can simply be a plain text file_).
* Setup Concordion in the project and create the 'runnable' BDD style tests that validate the acceptance criteria.

Notes:

* Use any IDE and build tool you like (_ant, maven, gradle_) or none at all (_we are mainly interested in the test files and source code_)
* A Concordion test is typically composed of an html spec and associated Java fixture classes that call into the system under test
* If Concordion is too much of a stretch then feel free to use Cucumber or another Java BBD tool that you are familiar with.
* There is no need to include any jar dependencies or build files in the solution (again we are mainly interested in the 'runnable' acceptance tests i.e. specification/feature files and associated java fixtures)