/*
 * Copyright:    Copyright (c) 2021
 * Company:      Insight Investment Management Limited
 */

package com.insightinvestment.order;

import java.time.LocalDate;

import com.insightinvestment.order.model.Allocation;
import com.insightinvestment.order.model.Execution;
import com.insightinvestment.order.model.Order;
import com.insightinvestment.order.prices.MarketPrices;
import com.insightinvestment.order.prices.RandomMarketPrices;

public class OrderExecutorDemo {

  public static void main(String[] args) {

    // Create access to some market prices
    MarketPrices marketPrices = new RandomMarketPrices(); // Random and Fixed implementations exist for testing

    // Create the order executor application
    OrderExecutor executor = new OrderExecutor(marketPrices);

    // The order to execute (has 3 allocations)
    Order order = Order.of(
          Allocation.of("EURGBP", LocalDate.of(2021, 4, 28),  1_000_000),
          Allocation.of("EURGBP", LocalDate.of(2021, 4, 28), -2_000_000),
          Allocation.of("EURGBP", LocalDate.of(2021, 4, 28),  3_000_000));

    // Execute the order
    Execution execution = executor.execute(order);

    // Execution result:
    System.out.println(execution);
  }

}
