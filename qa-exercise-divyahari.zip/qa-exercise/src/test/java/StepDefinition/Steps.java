package StepDefinition;

import com.insightinvestment.order.OrderExecutor;
import com.insightinvestment.order.model.Allocation;
import com.insightinvestment.order.model.Order;
import com.sun.istack.internal.NotNull;
import com.sun.org.apache.xpath.internal.operations.Or;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.insightinvestment.order.model.Allocation;
import com.insightinvestment.order.model.Execution;
import com.insightinvestment.order.model.Order;
import com.insightinvestment.order.prices.MarketPrices;
import org.junit.Assert;

public class Steps {

    Order order;
    List<Allocation> allocationLists;

    @Then("order application can accept more than one allocation successfully.")
    public void order_application_can_accept_more_than_one_allocation_successfully() {

        System.out.println("Pass");
    }

    @Given("Order application is opened")
    public void Order_application_is_opened() {
        System.out.println("Order application is opened");

        // Since there is no application URL to open, below step is a preparation for next step
        allocationLists = new ArrayList<Allocation>();


    }

    @When("trader attempts to add more than one allocation to the order")
    public void more_than_one_Allocation() {
        allocationLists.add(Allocation.of("A", LocalDate.now(), 100));
        allocationLists.add(Allocation.of("B", LocalDate.now(), 200));

        order = new Order(allocationLists);

        List<Allocation> listAll = order.getAllocations();

        if (listAll.size() > 0) {

            System.out.println("Order has more than 1 allocation");

        }

    }

    @When("trader attempts to order with no allocations")
    public void with_NoAllocations() {
        order = new Order(allocationLists);

        List<Allocation> listAll = order.getAllocations();

        if (listAll.size() <= 0 && listAll.isEmpty()) {

            System.out.println("Order has no allocation");

        }

    }


    @When("trader attempts to assign allocation without symbol")
    public void without_symbol() {

        allocationLists.add(Allocation.of("A", LocalDate.now(), 100));
        allocationLists.add(Allocation.of("B", LocalDate.now(), 200));

        order = new Order(allocationLists);
        OrderExecutor OrderExe = new OrderExecutor(null);
        OrderExe.checkSameSymbol(order);

    }

    @When("trader attempts to assign allocation with the same symbol")
    public void with_sameSymbol() {


        allocationLists.add(Allocation.of("A", LocalDate.now(), 100));
        allocationLists.add(Allocation.of("A", LocalDate.now(), 200));

        order = new Order(allocationLists);
        OrderExecutor OrderExe = new OrderExecutor(null);
        OrderExe.checkSameSymbol(order);

    }

    @When("trader attempts to assign allocation without Maturity date")
    public void without_MaturityDate() {

        allocationLists.add(Allocation.of("A", null, 100));
        allocationLists.add(Allocation.of("A", null, 200));

        order = new Order(allocationLists);
        OrderExecutor OrderExe = new OrderExecutor(null);
        OrderExe.checkSameMaturity(order);

    }

    @When("trader attempts to assign allocation with the Maturity date")
    public void with_sameMaturityDate() {

        allocationLists.add(Allocation.of("A", LocalDate.now(), 100));
        allocationLists.add(Allocation.of("B", LocalDate.now(), 200));

        order = new Order(allocationLists);
        OrderExecutor OrderExe = new OrderExecutor(null);
        OrderExe.checkSameMaturity(order);

    }

    @When("trader attempts to assign allocation without specifying any amount")
    public void no_amount() {


        allocationLists.add(Allocation.of("A", LocalDate.now(), 10));
        allocationLists.add(Allocation.of("B", LocalDate.now(), 10));

        order = new Order(allocationLists);
        OrderExecutor OrderExe = new OrderExecutor(null);
        OrderExe.checkNetZero(order);


    }

    @When("trader attempts to assign allocation with amount less than or equal to zero")
    public void amount_greaterThanZero() {

        allocationLists.add(Allocation.of("A", LocalDate.now(), 0));
        allocationLists.add(Allocation.of("B", LocalDate.now(), 0));

        order = new Order(allocationLists);
        OrderExecutor OrderExe = new OrderExecutor(null);

    }

    @And("orders has allocation with Symbol, Maturity date, Amount not less than zero")
    public void amount_lessThanZero() {
        allocationLists.add(Allocation.of("A", LocalDate.now(), 100));
        allocationLists.add(Allocation.of("B", LocalDate.now(), 200));
        order = new Order(allocationLists);
        MarketPrices prices = null;
        OrderExecutor orderExe = new OrderExecutor(null);

    }

    @When("Order is executed successfully with all valid required details")
    public void successful_orderExecution() {

        allocationLists.add(Allocation.of("A", LocalDate.now(), 100));
        allocationLists.add(Allocation.of("B", LocalDate.now(), 200));
        order = new Order(allocationLists);
        double prices = 3.3;
        OrderExecutor orderExe = new OrderExecutor(null);
        orderExe.execute(order);
    }

    @And("order is executed at the Current Market price")
    public void order_is_executed_at_the_Current_Market_price() {

    }

    @Then("order application should accept more than one allocation successfully")
    public void enter_username_and_password_and_sign_in_to_the_app() {
        System.out.println("Order accepts more allocation");

    }

    @Then("order application should display warning An order should have at least one allocation")
    public void atLeast_oneAllocation() {

        System.out.println("Order should have minimum one allocation");
    }

    @Then("order application should display warning An allocation should have Symbol associated to allocation")
    public void symbol_Allocation() {
        System.out.println("Order should have symbol associated to allocation");
    }

    @Then("order application should display the warning An allocation should have Maturity Date associated to allocation")
    public void WarningMessageForSameMaturityDate() {
        System.out.println("Display warning An allocation should have Maturity date associated to allocation");
    }


    @Then("order application should display warning An allocation should have amount associated to allocation")
    public void WarningMessageForAmount() {

        System.out.println("Display warning An allocation should have amount associated to allocation");
    }

    @Then("order execution should be successful")
    public void order_ExecutionSuccessful() {
        System.out.println("Order executed successful");
    }

    @Then("order application should display warning An allocation should have amount greater than zero associated to allocation")
    public void WarningMessageForAmountGreaterThanZero() {

        System.out.println("Display warning An allocation should have amount greater than zero associated to allocation");
    }

    @Then("order application execution result should show symbol, Maturity date, total amount and market price displayed correctly for the trader")
    public void executionResultValidation() {

        System.out.println("Order executed successful");
    }

}