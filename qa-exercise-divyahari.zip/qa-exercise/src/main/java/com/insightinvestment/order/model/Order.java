/*
 * Copyright:    Copyright (c) 2021
 * Company:      Insight Investment Management Limited
 */

package com.insightinvestment.order.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Order {

  private final List<Allocation> allocations;

  public Order(List<Allocation> allocations) {
    this.allocations = new ArrayList<>(allocations);
  }

  public static Order of(Allocation... allocations) {
    return new Order(Arrays.asList(allocations));
  }

  public List<Allocation> getAllocations() {
    return Collections.unmodifiableList(allocations);
  }

  public List<String> getSymbols() {
    return distinct(Allocation::getSymbol);
  }

  public List<LocalDate> getMaturities() {
    return distinct(Allocation::getMaturity);
  }

  public int getAmount() {
    return allocations.stream()
          .mapToInt(Allocation::getAmount)
          .sum();
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) { return true; }
    if (o == null || !getClass().equals(o.getClass())) { return false; }
    final Order order = (Order)o;
    return Objects.equals(allocations, order.allocations);
  }

  @Override
  public int hashCode() {
    return Objects.hash(allocations);
  }

  @Override
  public String toString() {
    return "Order{" + allocations + '}';
  }

  private  <T> List<T> distinct(Function<Allocation, T> valueExtractor) {
    return allocations.stream()
          .map(valueExtractor)
          .distinct()
          .collect(Collectors.toList());
  }

}
