/*
 * Copyright:    Copyright (c) 2021
 * Company:      Insight Investment Management Limited
 */

package com.insightinvestment.order.prices;

public interface MarketPrices {

  double getPrice(String symbol);

}
