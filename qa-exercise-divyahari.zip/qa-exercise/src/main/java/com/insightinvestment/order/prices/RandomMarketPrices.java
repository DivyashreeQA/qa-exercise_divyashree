/*
 * Copyright:    Copyright (c) 2021
 * Company:      Insight Investment Management Limited
 */

package com.insightinvestment.order.prices;

import java.security.SecureRandom;
import java.util.Random;

public class RandomMarketPrices implements MarketPrices {

  private final Random random = new SecureRandom();

  @Override
  public double getPrice(String symbol) {
    return random.nextDouble() + 0.5; // returns price between 0.5 and 1.5
  }

}
