/*
 * Copyright:    Copyright (c) 2021
 * Company:      Insight Investment Management Limited
 */

package com.insightinvestment.order.model;

import java.time.LocalDate;
import java.util.Objects;

public class Execution {

  private final String symbol;
  private final LocalDate maturity;
  private final int amount;
  private final double price;

  public Execution(
        String symbol,
        LocalDate maturity,
        int amount,
        double price) {
    this.symbol = symbol;
    this.maturity = maturity;
    this.amount = amount;
    this.price = price;
  }

  public String getSymbol() {
    return symbol;
  }

  public LocalDate getMaturity() {
    return maturity;
  }

  public int getAmount() {
    return amount;
  }

  public double getPrice() {
    return price;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) { return true; }
    if (o == null || !getClass().equals(o.getClass())) { return false; }
    final Execution execution = (Execution)o;
    return amount == execution.amount &&
          Double.compare(execution.price, price) == 0 &&
          Objects.equals(symbol, execution.symbol) &&
          Objects.equals(maturity, execution.maturity);
  }

  @Override
  public int hashCode() {
    return Objects.hash(symbol, maturity, amount, price);
  }

  @Override
  public String toString() {
    return "Execution{" +
          "symbol='" + symbol + '\'' +
          ", maturity=" + maturity +
          ", amount=" + amount +
          ", price=" + price +
          '}';
  }

}
