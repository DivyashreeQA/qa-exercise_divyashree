/*
 * Copyright:    Copyright (c) 2021
 * Company:      Insight Investment Management Limited
 */

package com.insightinvestment.order;

import java.time.LocalDate;
import java.util.List;

import com.insightinvestment.order.model.Allocation;
import com.insightinvestment.order.model.Execution;
import com.insightinvestment.order.model.Order;
import com.insightinvestment.order.prices.MarketPrices;

public class OrderExecutor {

  private final MarketPrices prices;

  public OrderExecutor(MarketPrices prices) {
    this.prices = prices;
  }

  public Execution execute(Order order) {
    checkAtLeastOne(order);
    checkSameSymbol(order);
    checkSameMaturity(order);
    checkNetZero(order);

    // safe because we know at least 1 allocation
    Allocation template = order.getAllocations().get(0);

    String symbol = template.getSymbol();
    LocalDate maturity = template.getMaturity();
    int amount = order.getAmount();
    double price = prices.getPrice(template.getSymbol());

    return new Execution(symbol, maturity, amount, price);
  }

  public void checkAtLeastOne(Order order) {
    if (order.getAllocations().isEmpty()) {
      throw new IllegalArgumentException("Attempted to execute order with no allocations");
    }
  }

  public void checkSameSymbol(Order order) {
    List<String> symbols = order.getSymbols();
    if (order.getSymbols().size() > 1) {
      throw new IllegalArgumentException("Attempted to execute order with multiple symbols " + symbols);
    }
  }

  public void checkSameMaturity(Order order) {
    List<LocalDate> maturities = order.getMaturities();
    if (maturities.size() > 1) {
      throw new IllegalArgumentException("Attempted to execute order with multiple maturities " + maturities);
    }
  }

  public void checkNetZero(Order order) {
    if (order.getAmount() == 0) {
      throw new IllegalArgumentException("Attempted to execute order of net zero amount");
    }
  }

}
