/*
 * Copyright:    Copyright (c) 2021
 * Company:      Insight Investment Management Limited
 */

package com.insightinvestment.order.model;

import java.time.LocalDate;
import java.util.Objects;

public class Allocation {

  private final String symbol;
  private final LocalDate maturity;
  private final int amount;

  public Allocation(
        String symbol,
        LocalDate maturity,
        int amount) {
    this.symbol = symbol;
    this.maturity = maturity;
    this.amount = amount;
  }

  public static Allocation of(
        String symbol,
        LocalDate maturity,
        int amount) {
    return new Allocation(
          symbol,
          maturity,
          amount);
  }

  public String getSymbol() {
    return symbol;
  }

  public LocalDate getMaturity() {
    return maturity;
  }

  public int getAmount() {
    return amount;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) { return true; }
    if (o == null || !getClass().equals(o.getClass())) { return false; }
    final Allocation allocation = (Allocation)o;
    return amount == allocation.amount &&
          Objects.equals(symbol, allocation.symbol) &&
          Objects.equals(maturity, allocation.maturity);
  }

  @Override
  public int hashCode() {
    return Objects.hash(symbol, maturity, amount);
  }

  @Override
  public String toString() {
    return "Allocation{" +
          "symbol='" + symbol + '\'' +
          ", maturity=" + maturity +
          ", amount=" + amount +
          '}';
  }

}
