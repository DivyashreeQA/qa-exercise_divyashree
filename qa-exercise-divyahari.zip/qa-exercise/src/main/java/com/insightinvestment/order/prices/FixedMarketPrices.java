/*
 * Copyright:    Copyright (c) 2021
 * Company:      Insight Investment Management Limited
 */

package com.insightinvestment.order.prices;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class FixedMarketPrices implements MarketPrices {

  private final Map<String, Double> prices = new HashMap<>();

  @Override
  public double getPrice(String symbol) {
    Double price = prices.get(symbol);
    if (Objects.isNull(price)) {
       throw new IllegalStateException("Unable to get market price for " + symbol);
    }
    return price;
  }

  void setPrice(String symbol, double price) {
    prices.put(symbol, price);
  }

}
